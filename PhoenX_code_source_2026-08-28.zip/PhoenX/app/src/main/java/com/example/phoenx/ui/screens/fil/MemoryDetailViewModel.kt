package com.example.phoenx.ui.screens.fil

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.example.phoenx.data.ai.OnDeviceAIManager
import com.example.phoenx.data.encryption.EncryptionManager
import com.example.phoenx.data.local.*
import com.example.phoenx.data.sync.SyncWorker
import com.example.phoenx.data.sync.toOfflineEntry
import com.example.phoenx.domain.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.io.FileOutputStream
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.graphics.Bitmap
import java.util.*
import javax.inject.Inject

import org.json.JSONArray
import com.example.phoenx.data.audio.PhoenXAudioRecorder
import org.json.JSONObject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MemoryDetailViewModel @Inject constructor(
    private val offlineEntryDao: OfflineEntryDao,
    private val encryptionManager: EncryptionManager,
    private val onDeviceAIManager: OnDeviceAIManager,
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore,
    private val functions: FirebaseFunctions,
    private val audioRecorder: com.example.phoenx.data.audio.PhoenXAudioRecorder,
    private val wavRecorder: com.example.phoenx.data.audio.WavAudioRecorder,
    private val sttManager: com.example.phoenx.data.audio.SpeechToTextManager,
    private val mediaManager: com.example.phoenx.data.media.MediaManager,
    private val preferenceManager: com.example.phoenx.data.preferences.PreferenceManager,
    private val livingLinkService: com.example.phoenx.data.living.LivingLinkService, // v9.4.27
    private val syncTrigger: com.example.phoenx.data.sync.SyncTrigger,
    private val heirEntryLoader: com.example.phoenx.data.heir.HeirEntryLoader,
    private val audioRecorderController: com.example.phoenx.data.audio.MemoryAudioRecorderController,
    private val memoryDeletionManager: com.example.phoenx.data.memory.MemoryDeletionManager,
    private val personSelectionManager: com.example.phoenx.data.memory.MemoryPersonSelectionManager,
    private val memoryMetadataUpdater: com.example.phoenx.data.memory.MemoryMetadataUpdater,
    private val mediaComplementManager: com.example.phoenx.data.memory.MemoryMediaComplementManager,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val isRecording: StateFlow<Boolean> = audioRecorderController.isRecording

    val isVoiceNoteOverlayOpen: StateFlow<Boolean> = audioRecorderController.isVoiceNoteOverlayOpen

    val sttPartialText = audioRecorderController.sttPartialText

    fun openVoiceNoteOverlay() {
        audioRecorderController.openVoiceNoteOverlay()
    }

    fun closeVoiceNoteOverlay() {
        audioRecorderController.closeVoiceNoteOverlay()
    }

    fun startAudioRecording() {
        audioRecorderController.startAudioRecording()
    }

    fun stopAudioRecording(parentId: String) {
        val file = audioRecorderController.stopAudioRecording()
        file?.let {
            addMediaComplement(parentId, it, "AUDIO", "Note vocale")
        }
    }

    private val _entryId = MutableStateFlow<String?>(null)
    private val _targetCreatorId = MutableStateFlow<String?>(null) // v9.4.27
    private val _firestoreEntry = MutableStateFlow<OfflineEntry?>(null) // v9.4.27

    private val _heirKey = MutableStateFlow<ByteArray?>(null)
    val heirKey: StateFlow<ByteArray?> = _heirKey.asStateFlow()

    enum class ProtocolStatus { VERIFYING, ACTIVATED, LOCKED }
    private val _protocolStatus = MutableStateFlow(ProtocolStatus.VERIFYING)
    val protocolStatus: StateFlow<ProtocolStatus> = _protocolStatus.asStateFlow()

    val hasSeenIncludeInBookNudge: StateFlow<Boolean> = preferenceManager.hasSeenIncludeInBookNudge
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun markIncludeInBookNudgeSeen() {
        viewModelScope.launch {
            preferenceManager.markIncludeInBookNudgeSeen()
        }
    }

    private val _deleteSuccess = MutableStateFlow(false)
    val deleteSuccess: StateFlow<Boolean> = _deleteSuccess.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _suggestedPersons = MutableStateFlow<List<SimplifiedPerson>>(emptyList())
    val suggestedPersons: StateFlow<List<SimplifiedPerson>> = _suggestedPersons.asStateFlow()

    val recipients: StateFlow<List<RecipientEntity>> = offlineEntryDao.getAllRecipients()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPacts: StateFlow<List<PactEntity>> = offlineEntryDao.getAllPacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Source de vérité hybride (v9.4.27 : Room ou Firestore)
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val entry: StateFlow<OfflineEntry?> = combine(_entryId, _targetCreatorId) { id, targetId ->
        id to targetId
    }.flatMapLatest { (id, targetId) ->
        if (id == null) return@flatMapLatest flowOf(null)

        val isHeirMode = targetId != null && targetId != auth.currentUser?.uid
        if (isHeirMode) {
            _firestoreEntry
        } else {
            offlineEntryDao.getEntryById(id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /**
     * Source de vérité unique pour les destinataires sélectionnés (remappés en DocIDs pour l'UI)
     */
    val selectedRecipientIds: StateFlow<List<String>> = entry
        .filterNotNull()
        .combine(recipients) { rawEntry, recipientsList ->
            rawEntry.recipientIds.split(",")
                .filter { it.isNotBlank() }
                .map { it.trim() }
                .map { persistentId ->
                    recipientsList.find { it.linkedUid == persistentId }?.id ?: persistentId
                }.distinct()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Source de vérité unique pour les personnes citées (v9.4.26 : Unifiée)
     * Réagit aux changements de personIds dans l'entrée.
     */
    val selectedPersons: StateFlow<List<SimplifiedPerson>> = combine(
        entry.filterNotNull().map { it.personIds }.distinctUntilChanged(),
        offlineEntryDao.getAllPersons(),
        offlineEntryDao.getAllRecipients(),
        offlineEntryDao.getAllWitnesses(),
        offlineEntryDao.getAllDepositaries()
    ) { idsCsv, persons, recipients, witnesses, depositaries ->
        val ids = idsCsv.split(",").filter { it.isNotBlank() }.map { it.trim() }.distinct()
        if (ids.isEmpty()) return@combine emptyList()

        val allSimplified = persons.toSimplified() +
                recipients.toSimplifiedRecipient() +
                witnesses.toSimplifiedWitness() +
                depositaries.toSimplifiedDepositary()

        // On inclut aussi "Moi" si présent dans les IDs
        val user = auth.currentUser
        val me = if (user != null && ids.contains("ME_${user.uid}")) {
            val displayName = if (user.displayName.isNullOrBlank()) "Moi" else user.displayName!!
            listOf(SimplifiedPerson(
                id = "ME_${user.uid}",
                name = displayName,
                photoUrl = user.photoUrl?.toString(),
                sourceType = "auteur",
                relationship = "Auteur",
                isMe = true
            ))
        } else emptyList()

        (allSimplified + me).filter { ids.contains(it.id) }.distinctBy { it.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _firestoreComplements = MutableStateFlow<List<OfflineEntry>>(emptyList()) // v9.4.27

    /**
     * CORRECTIF (reactivite) : flatMapLatest reste a l'ecoute en continu de la base de donnees
     * locale (Room), au lieu de faire une simple photo instantanee avec .first().
     * Resout le bug ou un media ajoute/supprime n'apparaissait/disparaissait qu'apres
     * etre sorti puis revenu sur le souvenir.
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val complements: StateFlow<List<OfflineEntry>> = combine(_entryId, _targetCreatorId) { id, targetId ->
        id to targetId
    }.flatMapLatest { (id, targetId) ->
        if (id == null) return@flatMapLatest flowOf(emptyList())

        val isHeirMode = targetId != null && targetId != auth.currentUser?.uid
        val sourceFlow = if (isHeirMode) {
            _firestoreComplements
        } else {
            offlineEntryDao.getComplements(id)
        }

        sourceFlow.onEach { result ->
            android.util.Log.d("PHOENX_MEMORY_OPEN_TRACE", "Complements: Mode=${if(isHeirMode) "Heir" else "Creator"}, count=${result.size}, entryId=$id")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Compléments avec payload DÉCHIFFRÉ (v9.4.27 : Pour liens externes)
     */
    val decryptedComplements: StateFlow<List<OfflineEntry>> = combine(complements, _heirKey, _protocolStatus) { list, key, status ->
        if (status != ProtocolStatus.ACTIVATED) return@combine list
        list.map { comp ->
            if (comp.encryptedPayload.isNotEmpty()) {
                try {
                    val decrypted = encryptionManager.decryptText(comp.encryptedPayload, key)
                    // On injecte le texte déchiffré dans mediaUrl si c'est une URL
                    val updatedMediaUrl = if (decrypted.startsWith("http")) decrypted else comp.mediaUrl
                    comp.copy(mediaUrl = updatedMediaUrl)
                } catch (e: Exception) { comp }
            } else comp
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Retourne la liste des compléments texte DÉCHIFFRÉS (v8.4)
     */
    val decryptedTextComplements: StateFlow<List<Pair<String, String>>> = combine(complements, _heirKey, _protocolStatus) { list, key, status ->
        when (status) {
            ProtocolStatus.VERIFYING -> emptyList()
            ProtocolStatus.LOCKED -> list.filter { it.entryType == "TEXT" || it.entryType == "THOUGHT" }
                .map { it.id to "Souvenir scellé" }
            ProtocolStatus.ACTIVATED -> list.filter { (it.entryType == "TEXT") || (it.entryType == "THOUGHT") }
                .map { it.id to encryptionManager.decryptText(it.encryptedPayload, key) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val decryptedContent: StateFlow<String> = combine(entry, _heirKey, _protocolStatus) { ent, key, status ->
        val eid = _entryId.value
        android.util.Log.d("PHOENX_MEMORY_OPEN_TRACE", "--- RECALCUL CONTENT --- id=$eid, Status: $status, Key: ${key != null}")

        when (status) {
            ProtocolStatus.VERIFYING -> "Vérification de l'accès..."
            ProtocolStatus.LOCKED -> "Souvenir scellé"
            ProtocolStatus.ACTIVATED -> {
                if (ent == null) {
                    android.util.Log.w("PHOENX_MEMORY_OPEN_TRACE", "Entry is NULL for id=$eid")
                    return@combine ""
                }
                try {
                    val res = encryptionManager.decryptText(ent.encryptedPayload, key)
                    android.util.Log.d("PHOENX_MEMORY_OPEN_TRACE", "SUCCÈS DECHIFFREMENT id=${ent.id}, length=${res.length}")
                    res
                } catch(e: Exception) {
                    android.util.Log.e("PHOENX_MEMORY_OPEN_TRACE", "ÉCHEC DECHIFFREMENT id=${ent.id}: ${e.message}", e)
                    "Contenu chiffré"
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    /**
     * Modèle structuré pour les items du Portrait (v8.5.7)
     */
    data class PortraitItem(val id: String?, val question: String, val answer: String)

    /**
     * Fusionne le contenu legacy et les nouveaux compléments atomiques (v8.5.7)
     */
    val structuredPortrait: StateFlow<List<PortraitItem>> = combine(decryptedContent, complements, _heirKey, _protocolStatus) { content, compList, key, status ->
        val list = mutableListOf<PortraitItem>()

        if (status == ProtocolStatus.VERIFYING) return@combine list
        if (status == ProtocolStatus.LOCKED && key != null) {
            // Uniquement les compléments atomiques pour les titres, mais contenu scellé
            compList.filter { it.parentEntryId == _entryId.value && it.entryType == "TEXT" }.forEach { comp ->
                list.add(PortraitItem(comp.id, comp.aiSummary, "Souvenir scellé"))
            }
            return@combine list
        }

        // 1. Parsing Legacy (v8.5.9 - Titres intelligents)
        if (content.isNotBlank()) {
            if (content.startsWith("[")) {
                try {
                    val arr = JSONArray(content)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val q = obj.getString("q")
                        val a = obj.getString("a")
                        val displayQ = q.ifBlank { if (a.length > 30) a.take(30) + "..." else a }
                        list.add(PortraitItem(null, displayQ, a))
                    }
                } catch (e: Exception) {
                    content.split("\n\n").forEach {
                        val title = if (it.length > 30) it.take(30) + "..." else it
                        list.add(PortraitItem(null, title, it))
                    }
                }
            } else {
                content.split("\n\n").forEach {
                    val title = if (it.length > 30) it.take(30) + "..." else it
                    list.add(PortraitItem(null, title, it))
                }
            }
        }

        // 2. Standard Atomique (Compléments liés)
        compList.filter { it.parentEntryId == _entryId.value && it.entryType == "TEXT" }.forEach { comp ->
            val decrypted = encryptionManager.decryptText(comp.encryptedPayload, key)
            if (list.none { it.answer == decrypted && it.question == comp.aiSummary }) {
                list.add(PortraitItem(comp.id, comp.aiSummary, decrypted))
            }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    fun loadEntry(id: String, creatorId: String? = null) {
        val cleanCreatorId = creatorId?.takeIf { it.isNotBlank() && !it.startsWith("{") && it != "null" }
        android.util.Log.d("PHOENX_ATELIER_TRACE", "MemoryDetailViewModel: brut=[$creatorId] nettoye=[$cleanCreatorId]")

        _entryId.value = id
        _targetCreatorId.value = cleanCreatorId

        if (cleanCreatorId != null && cleanCreatorId != auth.currentUser?.uid) {
            viewModelScope.launch {
                _protocolStatus.value = ProtocolStatus.VERIFYING
                try {
                    val loadResult = heirEntryLoader.load(cleanCreatorId, id)

                    // v9.4.27 Fix B : On ne verrouille que si on n'est pas déjà ACTIVATED
                    // (Empêche l'oscillation fatale identifiée dans les logs)
                    if (_protocolStatus.value != ProtocolStatus.ACTIVATED) {
                        _protocolStatus.value = if (loadResult.isActivated) ProtocolStatus.ACTIVATED else ProtocolStatus.LOCKED
                    }
                    android.util.Log.d("PHOENX_MEMORY_OPEN_TRACE", "Protocole check: isActivated=${loadResult.isActivated} -> Final status=${_protocolStatus.value}")

                    _heirKey.value = loadResult.heirKey
                    _firestoreEntry.value = loadResult.firestoreEntry
                    _firestoreComplements.value = loadResult.firestoreComplements

                } catch (e: Exception) {
                    android.util.Log.e("MemoryDetailVM", "Erreur chargement distant", e)
                    _protocolStatus.value = ProtocolStatus.LOCKED
                }
            }
        } else {
            _protocolStatus.value = ProtocolStatus.ACTIVATED
            _heirKey.value = null
        }
    }
    fun clearError() {
        _error.value = null
    }
    fun updateContent(newText: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateContent(id, newText)
        }
    }

    fun updateTitle(newTitle: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateTitle(id, newTitle)
        }
    }

    fun updateComplementTitle(complementId: String, newTitle: String) {
        viewModelScope.launch {
            memoryMetadataUpdater.updateComplementTitle(complementId, newTitle)
        }
    }

    fun updateComplementComment(complementId: String, newComment: String?) {
        viewModelScope.launch {
            memoryMetadataUpdater.updateComplementComment(complementId, newComment)
        }
    }

    fun updateComplementCover(complementId: String, imageUri: Uri) {
        viewModelScope.launch {
            memoryMetadataUpdater.updateComplementCover(complementId, imageUri)
        }
    }

    fun updateRecipients(newRecipientDocIds: List<String>) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateRecipients(id, newRecipientDocIds, recipients.value)
        }
    }

    fun toggleRecipient(docId: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.toggleRecipient(id, selectedRecipientIds.value, docId, recipients.value)
        }
    }
    private var searchJob: Job? = null

    fun searchPersons(query: String) {
        searchJob?.cancel()
        if (query.isBlank()) {
            _suggestedPersons.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(300)
            try {
                _suggestedPersons.value = personSelectionManager.searchAllPersons(query)
            } catch (e: Exception) {
                android.util.Log.e("MemoryDetailVM", "Erreur recherche personnes", e)
            }
        }
    }
    fun selectPerson(person: SimplifiedPerson) {
        val currentIds = entry.value?.personIds?.split(",")
            ?.filter { it.isNotBlank() }?.map { it.trim() } ?: emptyList()

        if (!currentIds.contains(person.id)) {
            val newList = currentIds + person.id
            updatePersonsInDb(newList)
        }
        _suggestedPersons.value = emptyList()
    }

    fun selectMe() {
        val user = auth.currentUser ?: return
        val meId = "ME_${user.uid}"
        val currentIds = entry.value?.personIds?.split(",")
            ?.filter { it.isNotBlank() }?.map { it.trim() } ?: emptyList()

        if (!currentIds.contains(meId)) {
            val newList = currentIds + meId
            updatePersonsInDb(newList)
        }
    }

    fun removePerson(personId: String) {
        val currentIds = entry.value?.personIds?.split(",")
            ?.filter { it.isNotBlank() }?.map { it.trim() } ?: emptyList()

        val newList = currentIds.filter { it != personId }
        updatePersonsInDb(newList)
    }

    fun createAndSelectPerson(
        firstName: String,
        lastName: String?,
        relationship: String?,
        distinctionType: String?,
        distinctionValue: String?,
        imageUri: Uri?,
        characterType: String = "HUMAN"
    ) {
        viewModelScope.launch {
            var finalImagePath: String? = null
            if (imageUri != null) {
                try {
                    val cameoDir = File(context.filesDir, "cameos")
                    if (!cameoDir.exists()) cameoDir.mkdirs()
                    val fileName = "cameo_${UUID.randomUUID()}.jpg"
                    val destFile = File(cameoDir, fileName)
                    context.contentResolver.openInputStream(imageUri)?.use { input ->
                        FileOutputStream(destFile).use { output -> input.copyTo(output) }
                    }
                    finalImagePath = destFile.absolutePath
                } catch (e: Exception) {
                    android.util.Log.e("CameoDebug", "Erreur sauvegarde portrait", e)
                }
            }

            try {
                val simplified = personSelectionManager.createPerson(
                    firstName, lastName, relationship, distinctionType, distinctionValue, finalImagePath, characterType
                )
                selectPerson(simplified)
            } catch (_: Exception) { }
        }
    }

    private fun updatePersonsInDb(ids: List<String>) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            offlineEntryDao.updateEntryPersons(ids.distinct().joinToString(","), id)
            syncTrigger.triggerSync(id)
        }
    }

    fun updateEnigma(
        question: String?,
        answer: String?,
        hint: String?,
        autoUnlockDays: Int?,
        isUltimate: Boolean
    ) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateEnigma(id, question, answer, hint, autoUnlockDays, isUltimate)
        }
    }

    fun updateEntryVisibility(entryId: String, visibility: String) {
        viewModelScope.launch {
            memoryMetadataUpdater.updateEntryVisibility(entryId, visibility)
        }
    }

    fun updateEntryRecipients(entryId: String, recipientDocIds: List<String>) {
        viewModelScope.launch {
            memoryMetadataUpdater.updateEntryRecipients(entryId, recipientDocIds, recipients.value)
        }
    }

    fun sendLivingLink(recipientUid: String, scheduledAt: Long? = null) {
        val entryId = _entryId.value ?: return
        viewModelScope.launch {
            try {
                livingLinkService.sendLivingLink(entryId, recipientUid, scheduledAt)
                _error.value = "Souvenir transmis avec succès !"
            } catch (e: Exception) {
                android.util.Log.e("LivingLink", "Erreur transmission", e)
                _error.value = "Échec de la transmission : ${e.message}"
            }
        }
    }

    fun updateVisibility(visibility: String) {
        val id = _entryId.value ?: return
        updateEntryVisibility(id, visibility)
    }

    fun updateSilentAttribution(silent: Boolean) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateSilentAttribution(id, silent)
        }
    }

    fun updateIncludeInBook(include: Boolean) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateIncludeInBook(id, include)
        }
    }

    fun updatePactId(pactId: String?) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updatePactId(id, pactId)
        }
    }

    fun updateCompartments(selectedIds: List<String>) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateCompartments(id, selectedIds)
        }
    }

    fun updateCategory(category: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateCategory(id, category)
        }
    }

    fun updateTonalNuance(nuance: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateTonalNuance(id, nuance)
        }
    }

    fun updateMemoryDate(date: Long?) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateMemoryDate(id, date)
        }
    }

    fun updateMemoryPeriod(start: Long?, end: Long?) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateMemoryPeriod(id, start, end)
        }
    }

    fun updateLocation(lat: Double?, lng: Double?, name: String?, locId: String?) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.updateLocation(id, lat, lng, name, locId)
        }
    }

    fun assignLocationFromId(locationId: String) {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            memoryMetadataUpdater.assignLocationFromId(id, locationId)
        }
    }
    fun deleteMemory() {
        val id = _entryId.value ?: return
        viewModelScope.launch {
            when (val outcome = memoryDeletionManager.deleteEntryById(id, isParent = true)) {
                is com.example.phoenx.data.memory.DeleteOutcome.Success -> _deleteSuccess.value = true
                is com.example.phoenx.data.memory.DeleteOutcome.Failure -> _error.value = outcome.message
            }
        }
    }
    fun deleteComplement(complementId: String) {
        viewModelScope.launch {
            when (val outcome = memoryDeletionManager.deleteEntryById(complementId, isParent = false)) {
                is com.example.phoenx.data.memory.DeleteOutcome.Success -> { }
                is com.example.phoenx.data.memory.DeleteOutcome.Failure -> _error.value = outcome.message
            }
        }
    }

    fun addMediaComplement(parentId: String, file: File, type: String, transcription: String? = null) {
        viewModelScope.launch {
            try {
                mediaComplementManager.addMediaComplement(parentId, file, type, transcription)
            } catch (e: Exception) {
                android.util.Log.e("MemoryDetailVM", "Erreur ajout média", e)
                _error.value = "Erreur lors de l'ajout du média"
            }
        }
    }

    fun uriToFile(uri: Uri): File? {
        return memoryMetadataUpdater.uriToFile(uri)
    }
}