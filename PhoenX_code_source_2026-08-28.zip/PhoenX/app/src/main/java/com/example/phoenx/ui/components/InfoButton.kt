package com.example.phoenx.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.phoenx.ui.theme.LocalAccentColor
import com.example.phoenx.ui.theme.LocalAppTheme

@Composable
fun InfoButton(
    title: String,
    points: List<String>,
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }
    val theme = LocalAppTheme.current
    val accent = theme.accentColor

    // Helper pour parser le gras ** (v9.4.27)
    val parseBold = @Composable { text: String ->
        buildAnnotatedString {
            val parts = text.split("**")
            parts.forEachIndexed { index, part ->
                if (index % 2 == 1) {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(part)
                    }
                } else {
                    append(part)
                }
            }
        }
    }

    // Le bouton ℹ️ discret (v9.2.6 : Harmonisé au thème)
    IconButton(
        onClick = { showDialog = true },
        modifier = modifier.size(36.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .background(
                    color = theme.contentColor.copy(alpha = 0.08f),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "i",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = theme.fontFamily
            )
        }
    }

    // La fenêtre d'information
    if (showDialog) {
        Dialog(onDismissRequest = { showDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = theme.backgroundColor
                ),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    // Titre
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontFamily = theme.fontFamily,
                            color = theme.contentColor
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Ligne dorée fine
                    HorizontalDivider(
                        color = accent.copy(alpha = 0.4f),
                        thickness = 1.dp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Points d'explication
                    points.forEach { point ->
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = "•",
                                color = accent,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(
                                    end = 8.dp, top = 2.dp
                                )
                            )
                            Text(
                                text = parseBold(point),
                                style = MaterialTheme.typography.bodyMedium,
                                color = theme.contentColor.copy(alpha = 0.7f),
                                lineHeight = 20.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Bouton fermer
                    TextButton(
                        onClick = { showDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            "Compris",
                            color = accent,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
