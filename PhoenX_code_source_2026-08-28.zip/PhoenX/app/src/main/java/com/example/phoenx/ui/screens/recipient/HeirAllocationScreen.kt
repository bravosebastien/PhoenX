package com.example.phoenx.ui.screens.recipient

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.phoenx.data.local.OfflineEntry
import com.example.phoenx.ui.navigation.Screen
import com.example.phoenx.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeirAllocationScreen(
    recipientId: String,
    navController: NavController,
    viewModel: RecipientViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val recipients = (uiState as? RecipientUiState.Success)?.recipients ?: emptyList()
    val recipient = recipients.find { it.id == recipientId }
    
    val entries by viewModel.getEntriesForRecipientUid(recipient?.linkedUid).collectAsState(initial = emptyList())
    
    val theme = LocalAppTheme.current
    val accent = theme.accentColor
    val backgroundBrush = LocalBackgroundBrush.current

    Scaffold(
        containerColor = theme.backgroundColor,
        modifier = Modifier.background(backgroundBrush),
        topBar = {
            TopAppBar(
                title = { 
                    val theme = LocalAppTheme.current
                    val accent = theme.accentColor
                    Column {
                        Text("Fiche Destinataire", style = MaterialTheme.typography.labelSmall, color = accent)
                        Text(recipient?.name ?: "Détails", style = MaterialTheme.typography.titleLarge.copy(fontFamily = theme.fontFamily, fontWeight = FontWeight.Bold), color = theme.contentColor)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = theme.contentColor)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Text(
                text = "${entries.size} souvenirs sont destinés à ${recipient?.name ?: "ce proche"}.",
                style = MaterialTheme.typography.bodyMedium,
                color = theme.contentColor.copy(alpha = 0.7f),
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(entries) { entry ->
                    AllocationEntryRow(
                        entry = entry,
                        theme = theme,
                        onClick = { 
                            if (entry.entryType == "PORTRAIT") {
                                // v9.2.6 : Redirection vers le vrai point d'édition
                                navController.navigate("portrait_proche?recipientId=$recipientId")
                            } else {
                                navController.navigate(Screen.MemoryDetail.createRoute(entry.id))
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AllocationEntryRow(
    entry: OfflineEntry,
    theme: AppThemeState,
    onClick: () -> Unit
) {
    val accent = theme.accentColor
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.FRENCH)
    val formattedDate = sdf.format(Date(entry.createdAt))

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 24.dp, vertical = 8.dp),
        color = Color.Transparent
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Icône Type
            val icon = when(entry.entryType) {
                "PHOTO", "GALLERY" -> Icons.Default.PhotoCamera
                "AUDIO" -> Icons.Default.Mic
                "VIDEO" -> Icons.Default.Videocam
                "PORTRAIT" -> Icons.Outlined.AccountCircle
                "QUESTION_ANSWER" -> Icons.AutoMirrored.Filled.HelpOutline
                else -> Icons.Default.Description
            }
            
            Surface(
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(12.dp),
                color = theme.contentColor.copy(alpha = 0.03f),
                border = BorderStroke(1.dp, theme.contentColor.copy(alpha = 0.1f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = accent.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                val title = when(entry.entryType) {
                    "PORTRAIT" -> entry.aiSummary
                    "QUESTION_ANSWER" -> "Ma réponse à : ${entry.aiSummary}"
                    else -> entry.aiSummary.ifEmpty { "Souvenir sans titre" }
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = theme.contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = theme.contentColor.copy(alpha = 0.4f)
                )
            }
            
            if (entry.visibility == "EVERYONE") {
                Surface(
                    color = accent.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text(
                        "PUBLIC", 
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
                        color = accent
                    )
                }
            }
        }
    }
}
