package com.example.phoenx.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "recipients")
data class RecipientEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val relationship: String,
    val accessLevel: String = "full", // "partial" | "full"
    val canAskQuestions: Boolean = false,
    val maxQuestionsAllowed: Int? = null,
    val questionsAskedCount: Int = 0,
    val accessToken: String? = null,
    val invitationSentAt: Long? = null,
    val invitationConfirmed: Boolean = false,
    val photoUrl: String? = null, // v9.2.2: Profile photo
    val createdAt: Long = System.currentTimeMillis(),
    val phone: String? = null, // v8.9.8
    val linkedUid: String? = null, // v9.2: Real Auth UID for security checks

    // AMBIANCE DE TRANSMISSION v9.4.27 (Migration v47)
    val transmissionBackgroundId: String = "classic_ivory",
    val transmissionFontId: String = "playfair_display",

    // v9.4.29 : Affichage des photos de proches dans le livre
    val showPersonPhotos: Boolean = false
)
