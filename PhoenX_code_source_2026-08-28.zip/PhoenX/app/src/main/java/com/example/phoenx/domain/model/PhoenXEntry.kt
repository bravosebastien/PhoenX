package com.example.phoenx.domain.model

import java.time.Instant

/**
 * Modèle de base pour une entrée dans le Fil de Pensée.
 */
data class PhoenXEntry(
    val id: String = "",
    val creatorUid: String = "",
    val timestamp: Instant = Instant.now(),
    val ageAtCreation: AgeSnapshot,
    val encryptedContent: ByteArray,
    val type: EntryType = EntryType.THOUGHT,
    val tags: List<String> = emptyList(),
    val isYoungSelfLetter: Boolean = false,
    val targetAge: Int? = null,
    val amendments: List<PhoenXAmendment> = emptyList(),
    
    // IA SIGNATURE 5.0
    val aiSummary: String = "",
    val userComment: String? = null, // v9.4.27 (Commentaire personnel)
    val aiTags: List<String> = emptyList(),
    val temporalEvolution: String? = null,
    
    // DÉTECTIVE & PROGRAMMATION (ADN 5.0)
    val hasEnigma: Boolean = false,
    val scheduledDate: Instant? = null,

    // GESTION STRUCTURELLE (Signature 7.6)
    val parentEntryId: String? = null,

    // MÉDIA (v8.4.5)
    val mediaUrl: String? = null,
    val localMediaPath: String? = null,
    
    // ENRICHISSEMENT MÉDIA v9.4.27
    val coverUrl: String? = null,
    val localCoverPath: String? = null,
    val mediaProvider: String? = null,

    // GESTION RÉSEAU (v8.9.2)
    val recipientIds: List<String> = emptyList(),
    val visibility: String = "RESTRICTED",
    val silentAttribution: Boolean = false,
    
    // MÉTA-DONNÉES DE SOURCE v9.4.27
    val sourceDocType: String = "entries",
    val personId: String? = null, // v9.6.6 : Pour résolution personMedia
    val isEncrypted: Boolean = true // v9.6.6
)

data class PhoenXAmendment(
    val id: String,
    val encryptedContent: ByteArray,
    val ageAtAmendment: AgeSnapshot,
    val createdAt: Instant
)

enum class EntryType {
    THOUGHT,
    EMOTION,
    LEGACY,
    PHOTO,
    AUDIO,
    VIDEO,
    PORTRAIT,
    QUESTION_ANSWER
}
